package com.example.alreadytalbt.User.Enums;


public enum Role {
    CUSTOMER,
    VENDOR,
    DELIVERY
}
